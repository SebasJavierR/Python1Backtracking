import random
from mapa import Mapa , Coord

def explorar(grilla,casilla_actual):
    n=random.randint(0,3)
    if n==0:
        if grilla.es_coord_valida(casilla_actual.trasladar(-2,0)) and grilla.celda_bloqueada(casilla_actual.trasladar(-2,0)):
            grilla.desbloquear(casilla_actual.trasladar(-2,0))
            grilla.desbloquear(casilla_actual.trasladar(-1,0))
            explorar(grilla,casilla_actual.trasladar(-2,0))
        else:
            return grilla
    if n==1:    
        if grilla.es_coord_valida(casilla_actual.trasladar(2,0)) and grilla.celda_bloqueada(casilla_actual.trasladar(2,0)):
            grilla.desbloquear(casilla_actual.trasladar(2,0))
            grilla.desbloquear(casilla_actual.trasladar(1,0))
            explorar(grilla,casilla_actual.trasladar(2,0))
        else:
            return grilla
    if n==2:
        if grilla.es_coord_valida(casilla_actual.trasladar(0,2)) and grilla.celda_bloqueada(casilla_actual.trasladar(0,2)):
            grilla.desbloquear(casilla_actual.trasladar(0,2))
            grilla.desbloquear(casilla_actual.trasladar(0,1))
            explorar(grilla,casilla_actual.trasladar(0,2))
        else:
            return grilla
    if n==3:
        if grilla.es_coord_valida(casilla_actual.trasladar(0,-2)) and grilla.celda_bloqueada(casilla_actual.trasladar(0,-2)):
            grilla.desbloquear(casilla_actual.trasladar(0,-2))
            grilla.desbloquear(casilla_actual.trasladar(0,-1))
            explorar(grilla,casilla_actual.trasladar(0,-2))
        else:
            return grilla
    

def generar_laberinto(filas, columnas):
    """Generar un laberinto.

    Argumentos:
        filas, columnas (int): Tamaño del mapa

    Devuelve:
        Mapa: un mapa nuevo con celdas bloqueadas formando un laberinto
              aleatorio
    """
    
    grilla = Mapa(filas,columnas)
    casilla_actual = grilla.origen()
    grilla = explorar(grilla,casilla_actual)
    return grilla



    


    